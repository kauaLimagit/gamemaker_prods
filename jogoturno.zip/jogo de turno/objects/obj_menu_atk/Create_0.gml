size_cursor_on = 1.3
mouse_on = false