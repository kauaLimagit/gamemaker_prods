if place_meeting(x,y,obj_pointer){
	image_xscale = size_cursor_on
	mouse_on = true
}else {
	image_xscale = 1
	mouse_on = false
}

if mouse_on == true {
	if mouse_check_button_pressed(mb_left){
		global.playeratk = true
	}
}