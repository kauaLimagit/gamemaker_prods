dirx = irandom_range(40,800)
diry = irandom_range(40,500)

timer = 120
vspd = 2

gothit = false

hp = 3
knockback = 20
cooldown = 60