enemy_qnt = 5

ecode = 0

timer = 240