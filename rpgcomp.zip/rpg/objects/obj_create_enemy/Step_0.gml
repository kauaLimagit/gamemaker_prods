if timer > 0{
	timer--
}

if timer == 0 {
	if enemy_qnt > 0 {
		ecode = irandom_range(1,2)
	}else {
		global.comand = true
	}
	
	switch(ecode){
		case 1:
			instance_create_layer(x,y,"Instances",obj_enemy_base_weak);
			break;
		case 2:
			instance_create_layer(x,y,"Instances", obj_enemy_base_l1);
			break;
	}
	
	enemy_qnt--
	ecode = 0
	timer = 240
}