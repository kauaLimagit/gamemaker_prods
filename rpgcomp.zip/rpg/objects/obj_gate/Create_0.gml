image_speed = 0

global.opengate = false