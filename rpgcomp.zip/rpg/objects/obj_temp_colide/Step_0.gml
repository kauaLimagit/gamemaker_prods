if global.comand {
	global.opengate = true
	instance_destroy(self)
}